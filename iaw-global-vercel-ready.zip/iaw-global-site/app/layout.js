import './globals.css';
import { Inter, DM_Serif_Display } from 'next/font/google';

const inter = Inter({ subsets:['latin'], variable:'--font-inter' });
const serif = DM_Serif_Display({ subsets:['latin'], weight:'400', variable:'--font-serif' });

export const metadata = { title:'IAW Global | Connecting Agriculture. Creating Global Opportunities.', description:'IAW Global connects quality agricultural products with growing markets around the world.' };
export default function RootLayout({children}){ return <html lang="en"><body className={`${inter.variable} ${serif.variable}`}>{children}</body></html>; }
