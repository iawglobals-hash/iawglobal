# IAW Global Website

Next.js website for IAW Global, built from the supplied website content.

## Run locally
npm install
npm run dev

## Deploy on Vercel
1. Push this folder to GitHub/GitLab/Bitbucket, or import the ZIP contents into a repository.
2. In Vercel, select the repository.
3. Framework preset: Next.js (auto-detected).
4. Build command: `npm run build`.
5. Output directory: leave default.
6. Add custom domain `iawglobal.in` after deployment.

No environment variables are required for the current static site.
